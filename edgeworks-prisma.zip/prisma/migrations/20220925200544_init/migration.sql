-- CreateTable
CREATE TABLE "EdgeworksLog" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "date" DATETIME NOT NULL,
    "climbers" INTEGER NOT NULL
);
